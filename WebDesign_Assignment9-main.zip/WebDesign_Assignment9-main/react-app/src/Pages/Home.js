import React from 'react';
import Home from '../Components/Home';

const HomePage = () => {
  return <Home />;
};

export default HomePage;
