import React from 'react';
import Jobs from '../Components/Jobs';

const JobsPage = () => {
  return <Jobs />;
};

export default JobsPage;
