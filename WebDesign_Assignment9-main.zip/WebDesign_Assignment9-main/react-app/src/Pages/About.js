import React from 'react';
import About from '../Components/About';

const AboutPage = () => {
  return <About />;
};

export default AboutPage;
