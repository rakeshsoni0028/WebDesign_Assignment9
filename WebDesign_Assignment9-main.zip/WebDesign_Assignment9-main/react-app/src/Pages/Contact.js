import React from 'react';
import Contact from '../Components/Contact';

const ContactPage = () => {
  return <Contact />;
};

export default ContactPage;
