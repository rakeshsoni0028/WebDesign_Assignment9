import React from 'react';
import Login from '../Components/Login';
//import SignInSide from '../Components/CustomLogin';

const LoginPage = () => {
  return <Login />;
};

export default LoginPage;
